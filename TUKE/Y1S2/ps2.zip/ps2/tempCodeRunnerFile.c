    // for(int rows = 0; rows < SIZE; rows++){
    //     for(int cols = 0; cols < SIZE-1; cols++){
    //         if(game.board[rows][cols] == game.board[rows][cols+1] || game.board[rows][cols+1]==' ') return true;
    //     }
    // }